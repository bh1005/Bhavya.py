'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''

from math import pi
r= float(input("Input the radius of the circle :"))
print("The area of the circle with radius 1.1 is: " + str(pi * r**2))

